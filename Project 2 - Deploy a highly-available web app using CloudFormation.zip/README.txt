This project is the 2nd project in advanced devops track nano degree, this project includes the below files:

- Project design file: "UdacityProject2 - Design.png"
- Project resources file: "UdacityProject2.yml"
- Project parameters file: "UdacityProject2-Parameters.json"
- Screenshot shows accessing the application URL through load balancer: "Working Test.png"
- Screenshot show LoadBalancer URL in the output parameters after running UdacityProject2 stack; "URL-Output.png"
- Application working URL: http://udaci-webap-1y881pmtfqu3-173572373.us-east-1.elb.amazonaws.com/